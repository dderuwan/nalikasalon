<?php $__env->startSection('content'); ?>
<main role="main" class="main-content">
  <div class="container-fluid">
    <div class="row justify-content-center">
      <div class="col-12">
        <h3 class="page-title"> Leave Application</h3>
        <div class="card-deck">
          <div class="card shadow mb-4">
            <div class="card-header">
              <strong class="card-title">Edit Application</strong>
            </div>
            <div class="card-body p-4">
              <form method="POST" action="<?php echo e(route('leave_app_update', $leave_applications->id)); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?> <!-- Add this line for updating -->
                <div class="form-row">
                  <div class="form-group col-md-6">
                    <label for="inputEmployee" style="color:black;">Employee Name <i class="text-danger">*</i></label>
                    <select class="form-control" id="inputEmployee" name="employee_id">
                      <option value="">Select Employee</option>
                      <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($employee->id); ?>" <?php echo e($leave_applications->employee_id == $employee->id ? 'selected' : ''); ?>>
                          <?php echo e($employee->id); ?>-<?php echo e($employee->firstname); ?> <?php echo e($employee->lastname); ?>

                        </option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['employee_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <div class="form-group col-md-6">
                    <label for="inputLeaveType" style="color:black;">Leave Type <i class="text-danger">*</i></label>
                    <select class="form-control" id="inputLeaveType" name="leave_type_id">
                      <option value="">Select Leave Type</option>
                      <?php $__currentLoopData = $leaveTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leaveType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($leaveType->id); ?>" <?php echo e($leave_applications->leave_type_id == $leaveType->id ? 'selected' : ''); ?>>
                          <?php echo e($leaveType->leave_type); ?>

                        </option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['leave_type_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                </div>

                <div class="form-row">
                  <div class="form-group col-md-6">
                    <label for="apply_strt_date" style="color:black;">Application Start Date<i class="text-danger">*</i></label>
                    <input type="date" class="form-control" id="apply_strt_date" name="apply_strt_date" value="<?php echo e($leave_applications->apply_strt_date); ?>">
                    <?php $__errorArgs = ['apply_strt_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <div class="form-group col-md-6">
                    <label for="apply_end_date" style="color:black;">Application End Date<i class="text-danger">*</i></label>
                    <input type="date" class="form-control" id="apply_end_date" name="apply_end_date" value="<?php echo e($leave_applications->apply_end_date); ?>">
                    <?php $__errorArgs = ['apply_end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                </div>

                <div class="form-row">
                  <div class="form-group col-md-6">
                    <label for="apply_day" style="color:black;">Apply Day</label>
                    <input type="text" class="form-control" id="apply_day" name="apply_day" value="<?php echo e($leave_applications->apply_day); ?>" readonly>
                  </div>
                  <div class="form-group col-md-6">
                    <label for="apply_hard_copy" style="color:black;">Application</label>
                    <input type="file" class="form-control" id="apply_hard_copy" name="apply_hard_copy">
                    <?php if($leave_applications->apply_hard_copy): ?>
                      <p>Current File: <a href="<?php echo e(asset('storage/'.$leave_applications->apply_hard_copy)); ?>" target="_blank">View File</a></p>
                    <?php endif; ?>
                    <?php $__errorArgs = ['apply_hard_copy'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                </div>

                <div class="form-row">
                  <div class="form-group col-md-6">
                    <label for="leave_aprv_strt_date" style="color:black;">Approve Start Date</label>
                    <input type="date" class="form-control" id="leave_aprv_strt_date" name="leave_aprv_strt_date" value="<?php echo e($leave_applications->leave_aprv_strt_date); ?>">
                    <?php $__errorArgs = ['leave_aprv_strt_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <div class="form-group col-md-6">
                    <label for="leave_aprv_end_date" style="color:black;">Approve End Date</label>
                    <input type="date" class="form-control" id="leave_aprv_end_date" name="leave_aprv_end_date" value="<?php echo e($leave_applications->leave_aprv_end_date); ?>">
                    <?php $__errorArgs = ['leave_aprv_end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                </div>

                <div class="form-row">
                  <div class="form-group col-md-6">
                    <label for="num_aprv_day" style="color:black;">Approved Day</label>
                    <input type="text" class="form-control" id="num_aprv_day" name="num_aprv_day" value="<?php echo e($leave_applications->num_aprv_day); ?>" readonly>
                  </div>
                  <div class="form-group col-md-6">
                    <label for="inputapproved_by" style="color:black;">Approved By</label>
                    <input type="text" class="form-control" id="inputapproved_by" name="approved_by" value="<?php echo e($leave_applications->approved_by); ?>">
                    <?php $__errorArgs = ['approved_by'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                </div>

                <div class="form-group">
                  <label for="inputreason" style="color:black;">Reason</label>
                  <input type="text" class="form-control" id="inputreason" name="reason" value="<?php echo e($leave_applications->reason); ?>">
                  <?php $__errorArgs = ['reason'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <p class="text-danger"><?php echo e($message); ?></p>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <button type="submit" class="btn btn-primary">Update</button>
              </form>
            </div>
          </div>
        </div> 
      </div> 
    </div> 
  </div> 
</main> 

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
  document.addEventListener('DOMContentLoaded', function () {
    function calculateDays(startDate, endDate, resultField) {
      const start = new Date(startDate.value);
      const end = new Date(endDate.value);

      if (start && end) {
        const diffTime = Math.abs(end - start);
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)); 
        resultField.value = diffDays;
      } else {
        resultField.value = '';
      }
    }

    const applyStartDate = document.getElementById('apply_strt_date');
    const applyEndDate = document.getElementById('apply_end_date');
    const applyDayField = document.getElementById('apply_day');

    const approveStartDate = document.getElementById('leave_aprv_strt_date');
    const approveEndDate = document.getElementById('leave_aprv_end_date');
    const approveDayField = document.getElementById('num_aprv_day');

    applyStartDate.addEventListener('change', function () {
      calculateDays(applyStartDate, applyEndDate, applyDayField);
    });

    applyEndDate.addEventListener('change', function () {
      calculateDays(applyStartDate, applyEndDate, applyDayField);
    });

    approveStartDate.addEventListener('change', function () {
      calculateDays(approveStartDate, approveEndDate, approveDayField);
    });

    approveEndDate.addEventListener('change', function () {
      calculateDays(approveStartDate, approveEndDate, approveDayField);
    });
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\project weeks\b4\wellwornsl-project\nalikasalon\resources\views/humanResources/leave/leave_app_update.blade.php ENDPATH**/ ?>