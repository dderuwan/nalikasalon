

<?php $__env->startSection('content'); ?>
<main role="main" class="main-content">
    <div class="container">
        <h1>GOODS IN NOTE</h1>
        <form action="<?php echo e(route('insertgin')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group pb-10">
                <label for="order_request_code">Order Request Code *</label>
                <select name="order_request_code" class="form-control" id="order_request_code" required>
                    <option value="">Select Order</option>
                    <?php $__currentLoopData = $orderRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderRequest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($orderRequest->order_request_code); ?>"><?php echo e($orderRequest->order_request_code); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div id="order-details" style="display: none;">
                <h3>Order Details</h3>
                <p><strong>Order Request Code:</strong> <span id="order-request-code"></span></p>
                <p><strong>Supplier:</strong> <span id="supplier-name"></span></p>
                <p><strong>Ordered Date:</strong> <span id="ordered-date"></span></p>
                <input type="hidden" name="supplier_code" id="supplier_code">
                <input type="hidden" name="date" id="date">
            </div>

            <table class="table table-bordered" id="items-table">
                <thead>
                    <tr>
                        <th style='color:Black'>Item Code</th>
                        <th style='color:Black'>Ordered Count</th>
                        <th style='color:Black'>Pack Size <span style='color:Red'>*<span ></th>
                        <th style='color:Black'>Unit Price <span style='color:Red'>*<span ></th>
                        <th style='color:Black'>In Quantity <span style='color:Red'>*<span ></th>
                        <th style='color:Black'>Shots Count </th>
                        <th style='color:Black'>Manufacture Date <span style='color:Red'>*<span ></th>
                        <th style='color:Black'>Expire Date <span style='color:Red'>*<span ></th>
                        <th style='color:Black'>Total Cost</th>
                        <th style='color:Black'>Payment</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Rows will be dynamically added here -->
                </tbody>
            </table>
            <button type="submit" class="btn btn-success">Submit</button>
        </form>
    </div>
</main>

<script>
    const orderRequests = <?php echo json_encode($orderRequests, 15, 512) ?>;

    document.getElementById('order_request_code').addEventListener('change', function() {
        const orderRequestCode = this.value;
        const orderDetails = document.getElementById('order-details');
        const tableBody = document.getElementById('items-table').getElementsByTagName('tbody')[0];

        // Clear existing rows
        tableBody.innerHTML = '';

        if (orderRequestCode) {
            const selectedOrder = orderRequests.find(order => order.order_request_code === orderRequestCode);

            if (selectedOrder && selectedOrder.items) {
                selectedOrder.items.forEach((item, index) => {
                    const newRow = tableBody.insertRow();
                    newRow.innerHTML = `
                    <tr>
                        <td><input type="text" name="orderItems[${index}][item_code]" class="form-control" value="${item.item_code}" readonly></td>
                        <td><input type="text" name="orderItems[${index}][quantity]" class="form-control" value="${item.quantity}" readonly></td>
                        <td><input type="number" name="orderItems[${index}][pack_size]" class="form-control"></td>
                        <td><input type="number" name="orderItems[${index}][unit_price]" class="form-control unit-price" data-index="${index}" required></td>
                        <td><input type="number" name="orderItems[${index}][in_quantity]" class="form-control in-quantity" data-index="${index}" required></td>
                        <td><input type="number" name="orderItems[${index}][shots_count]" class="form-control shots-count" data-index="${index}" ></td>
                        <td><input type="date" name="orderItems[${index}][manufacture_date]" class="form-control manufacture-date" data-index="${index}" required></td>
                        <td><input type="date" name="orderItems[${index}][expire_date]" class="form-control expire-date" data-index="${index}" required></td>
                        <td><input type="number" name="orderItems[${index}][total_cost]" class="form-control total-cost" data-index="${index}" readonly></td>
                        <td>
                            <select name="orderItems[${index}][payment]" class="form-control" required>
                                <option value="paid">Paid</option>
                                <option value="not_paid">Not Paid</option>
                            </select>
                        </td>
                    </tr>
                    `;
                });

                // Add event listeners for unit price and in quantity fields to calculate total cost
                document.querySelectorAll('.unit-price, .in-quantity').forEach(element => {
                    element.addEventListener('input', calculateTotalCost);
                });

                document.getElementById('order-request-code').textContent = selectedOrder.order_request_code;
                document.getElementById('supplier-name').textContent = selectedOrder.supplier_code;
                document.getElementById('ordered-date').textContent = selectedOrder.date;
                document.getElementById('supplier_code').value = selectedOrder.supplier_code;
                document.getElementById('date').value = selectedOrder.date;
                orderDetails.style.display = 'block';
            }
        }
    });

    function calculateTotalCost(event) {
        const index = event.target.dataset.index;
        const unitPrice = parseFloat(document.querySelector(`input[name="orderItems[${index}][unit_price]"]`).value) || 0;
        const inQuantity = parseFloat(document.querySelector(`input[name="orderItems[${index}][in_quantity]"]`).value) || 0;
        const totalCost = unitPrice * inQuantity;
        document.querySelector(`input[name="orderItems[${index}][total_cost]"]`).value = totalCost.toFixed(2);
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\project weeks\b4\wellwornsl-project\nalikasalon\resources\views/gin/create.blade.php ENDPATH**/ ?>