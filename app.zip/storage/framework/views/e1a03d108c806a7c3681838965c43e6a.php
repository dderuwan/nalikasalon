

<?php $__env->startSection('content'); ?>
<main role="main" class="main-content">
    <div class="container">
        <h2>Purchase Orders List</h2>
        <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success">
                <p><?php echo e($message); ?></p>
            </div>
        <?php endif; ?>
        <a href="<?php echo e(route('orderrequests.create')); ?>" class="btn btn-primary mb-3">Create New Order</a>
        <table class="table table-bordered">
            <tr>
                <th>Order-Request-Code</th>
                <th>Supplier Code</th>
                <th>Date</th>
                <th>Status</th>
                <th width="200px">Action</th>
            </tr>
            <?php $__currentLoopData = $orderRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderRequest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($orderRequest->order_request_code); ?></td>
                <td><?php echo e($orderRequest->supplier_code); ?></td>
                <td><?php echo e($orderRequest->date); ?></td>
                <td><?php echo e($orderRequest->status); ?></td>
                <td>
                    <!-- Show Button -->
                    <a href="<?php echo e(route('orderrequests.show', $orderRequest->id)); ?>" class="btn btn-secondary"><i class="fe fe-eye fe-16"></i></a>

                    <!-- Delete Button -->
                    <button class="btn btn-danger" onclick="confirmDelete(<?php echo e($orderRequest->id); ?>)"><i class="fe fe-trash fe-16"></i></button>
                    <form id="delete-form-<?php echo e($orderRequest->id); ?>" action="<?php echo e(route('orderrequests.destroy', $orderRequest->id)); ?>" method="POST" style="display:none;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    function confirmDelete(orderRequestId) {
        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
            if (result.isConfirmed) {
                document.getElementById('delete-form-' + orderRequestId).submit();
            }
        })
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\project weeks\b4\wellwornsl-project\nalikasalon\resources\views/orderrequests/index.blade.php ENDPATH**/ ?>