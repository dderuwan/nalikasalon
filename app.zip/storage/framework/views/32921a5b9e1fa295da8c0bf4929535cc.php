
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">


<link rel="stylesheet"href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
<link href="/assets/bootstrap/css/bootstrap.css" rel="stylesheet">
<link href="/assets/plugins/animate.min.css" rel="stylesheet">
<link href="/assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="/assets/plugins/themify/themify-icons.css" rel="stylesheet">
<link href="/assets/plugins/fontawesome/css/all.min.css" rel="stylesheet">
<link href="assets/plugins/owl-carousel/dist/assets/owl.carousel.min.css" rel="stylesheet">
<link href="/assets/sweetalert/sweetalert.css" rel="stylesheet" type="text/css"/>
<link href="/assets/plugins/owl-carousel/dist/assets/owl.theme.default.min.css" rel="stylesheet">
<link href="/assets/plugins/select2/dist/css/select2.min.css" rel="stylesheet">
<link href="/assets/plugins/select2/dist/css/select2-bootstrap.min.css" rel="stylesheet">
<link href="/assets/plugins/daterangepicker/daterangepicker.css" rel="stylesheet">
<link href="/assets/plugins/fancybox/dist/jquery.fancybox.min.css" rel="stylesheet">
<script src="/assets/plugins/jQuery/jquery-3.5.1.min.js"></script>
<link href="https://fonts.googleapis.com/css?family=Caveat:400,700|Playfair+Display:400,400i,700,700i,900,900i|Sarabun:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800&display=swap" rel="stylesheet" />
<link href="https://unpkg.com/feather-icons@4.28.0/dist/feather.css" rel="stylesheet">
<link href="https://stackpath.bootstrapcdn.com/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/glightbox/dist/css/glightbox.min.css" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;700&display=swap" rel="stylesheet">

<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap">
<?php /**PATH E:\project weeks\b4\wellwornsl-project\nalikasalon\resources\views/layouts/web/css.blade.php ENDPATH**/ ?>