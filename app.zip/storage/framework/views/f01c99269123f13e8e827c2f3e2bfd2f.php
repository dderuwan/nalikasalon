<!-- orderrequests/show.blade.php -->


<?php $__env->startSection('content'); ?>
<main role="main" class="main-content">
    <div class="container">
        <h1>Order Request Details</h1>
        <div class="mb-3">
            <a href="<?php echo e(route('allorderrequests')); ?>" class="btn btn-secondary"><i class="fe fe-arrow-left fe-16"></i></a>
            <button class="btn btn-danger" onclick="confirmDelete(<?php echo e($orderRequest->id); ?>)"><i class="fe fe-trash fe-16"></i></button>
             <form id="delete-form-<?php echo e($orderRequest->id); ?>" action="<?php echo e(route('orderrequests.destroy', $orderRequest->id)); ?>" method="POST" style="display:none;">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
            </form>
        </div>
        <p><strong>Order Request Code:</strong> <?php echo e($orderRequest->order_request_code); ?></p>
        <p><strong>Supplier Code:</strong> <?php echo e($orderRequest->supplier_code); ?></p>
        <p><strong>Date:</strong> <?php echo e($orderRequest->date); ?></p>

        <h2>Items</h2>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Item Code</th>
                    <th>In Stock</th>
                    <th>Quantity</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $orderRequest->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->item_code); ?></td>
                        <td><?php echo e($item->instock); ?></td>
                        <td><?php echo e($item->quantity); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        
    </div>
</main>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    function confirmDelete(orderRequestId) {
        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
            if (result.isConfirmed) {
                document.getElementById('delete-form-' + orderRequestId).submit();
            }
        })
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\project weeks\b4\wellwornsl-project\nalikasalon\resources\views/orderrequests/show.blade.php ENDPATH**/ ?>